export class Tokens {
  jwt = '';
  refreshToken = '';
  hotelname: any = 'NAME';
  chefname:any = 'NAME';
}
