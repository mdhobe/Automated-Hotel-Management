import { Component, OnInit } from '@angular/core';
import { ChefloginService } from '../services/cheflogin.service';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-cheflogin',
  templateUrl: './cheflogin.component.html',
  styleUrls: ['./cheflogin.component.css']
})
export class ChefloginComponent implements OnInit {

  constructor(private chefloginService: ChefloginService,
    private router: Router,
    public dialogRef: MatDialogRef<ChefloginComponent>) { }

  ngOnInit(): void {
  }

  cheflogin(chefinfo : any){
    this.chefloginService.login(
      {
        username: chefinfo.chefusername,
        password: chefinfo.chefpassword
      }
    )
      .subscribe(success => {
        if (success) {
          this.dialogRef.close()
          this.router.navigate(['/chef']);
        }
      });
  }
}
